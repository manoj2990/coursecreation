
import CourseCreationWizard from "@/components/CourseCreationWizard";

const Index = () => {
  return <CourseCreationWizard />;
};

export default Index;
